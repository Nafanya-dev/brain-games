### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nafanya-dev/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Nafanya-dev/python-project-49/actions)

<a href="https://codeclimate.com/github/Nafanya-dev/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f2d779b4b605d3977099/maintainability" /></a>
